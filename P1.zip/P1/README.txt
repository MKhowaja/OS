==========================
RTX P1 README
==========================

Team Members: Mustaqeem, Xiaowen, Hanyu, Junji

Description of Directory Contents:
-Contains a folder called P1
-Inside P1 there are object files and the project file for Keil uVision
-There is a src folder here which contains source code files
-The test user processes are in usr_proc.c inside the src folder