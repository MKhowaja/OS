==========================
RTX P2 README
==========================

Team Members: Mustaqeem, Xiaowen, Hanyu, Junji

Description of Directory Contents:
-Contains a folder called P2
-Inside P2 there are object files and the project file for Keil uVision
-There is a src folder here which contains source code files
-The test user processes are in usr_proc.c inside the src folder
-The 24 hour wall clock display process is in usr_clock.c inside the src folder

To see the contents of the ready, block on memory and block on message queues, 
enable the _DEBUG_HOTKEYS flag and then input '!' for ready, ',' for blocked 
on memory and '.' for blocked on message