//1.command reg
//2.keyboard input, forward to crt
void kcd(){

}

//crt request, call uart_i_process to display
void crt(){

}
