/**
 * @file:   kernel_proc.h
 */
 
#ifndef KERNEL_PROC_H_
#define KERNEL_PROC_H

void set_test_procs(void);
void nullProc(void);
void crt(void);
void kcd (void);
void uart_i_process(void);
#endif /* USR_PROC_H_ */
