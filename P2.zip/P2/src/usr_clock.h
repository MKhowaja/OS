/**
 * @file:   usr_clock.h
 */
 
#ifndef USR_CLOCK_H_
#define USR_CLOCK_H

void set_test_procs(void);

//wall clock user test process
void clock_proc(void);

#endif /* USR_CLOCK_H_ */
